public class Utils {
    public static void sayHello() {
        System.out.println("Hello, World!");
    }
}