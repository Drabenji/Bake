public class ElCycle {
    public static void sayBye() {
        System.out.println("Soy el méchant cycle >:D ! Hasta la vista baby !");
        Utils utils = new Utils();
        utils.ayCaramba();
    }
}
