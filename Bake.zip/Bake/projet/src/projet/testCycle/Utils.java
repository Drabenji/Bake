public class Utils {
    public static void sayHello() {
        System.out.println("Hello, World!");
        ElCycle cycle = new ElCycle();
        cycle.sayBye();
    }

    public void ayCaramba(){
        System.out.println("¡Ay, caramba!");
    }
}